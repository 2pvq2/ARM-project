#include "stm32f10x.h"                  // Device header
#include "stm32f10x_gpio.h"             // Keil::Device:StdPeriph Drivers:GPIO
#include "stm32f10x_rcc.h"              // Keil::Device:StdPeriph Drivers:RCC
#include "string.h"
#include "stdio.h"

#define MAX 100

char 	vrc_Getc; 			// bien kieu char, dung de nhan du lieu tu PC gui xuong;
int		vri_Stt; 			// bien danh dau trang thai. 
int 	vri_Count = 0; 		// bien diem
char	vrc_b1[MAX]; 		//Mang kieu char vrc_Res[MAX]: mang luu tru so thu nhat;
char	vrc_b2[MAX]; 		//Mang kieu char vrc_Res[MAX]: mang luu tru so thu hai;
unsigned int NUM[]={0xc0,0xf9,0xa4,0xb0,0x99,0x92,0x82,0xf8,0x80,0x90};
int kt1=0,kt2=0; // kiem tra da nhan so thu nhat va so thu hai
// kt1==1 => dang nhap so thu nhat; kt1==2 da nhap xong so thu nhat

void Delay_ms(uint16_t _time);
void uart_Init(void);
void uart_SendChar(char _chr);
void uart_SendStr(char *str);
void led_Init(void);
void ledcontrol_Init(void);
void led_Counter1(void);
uint16_t UARTx_Getc(USART_TypeDef* USARTx);


int main(){
	uart_Init();	
	led_Init();
	ledcontrol_Init();
	int	vrc_kq[MAX] = {0};   //Mang luu ket qua nhan
	
	while(1){

	// CHuong Trinh nhan 2 so nhi phan 3 bit		
		
		if(kt1 == 2 && kt2 == 2 ){  // kiem tra ket qua dau vao
			int i,j , du=0;
			for ( i=0; i<=MAX ; i++) vrc_kq[i] = 0;
			
		//nhan 2 so nhi phan
			for (i=7; i>=0; i--)
				{
					du = 0;
					for (j=7; j>=0; j--)
					{			
						int x = vrc_b1[i] - '0';
						int y = vrc_b2[j] - '0';
						vrc_kq[i+j] += x * y + du;
						if (vrc_kq[i+j] > 1 ) 
						{
							du = vrc_kq[i+j] - (vrc_kq[i+j] % 2) - 1;
							vrc_kq[i+j] = vrc_kq[i+j] % 2; 
						}
						else du=0;
					}
					if (du != 0) vrc_kq[i+j-1] = 1;
				}
					for (i=7; i<=14 ; i++) printf ("%d",vrc_kq[i]);
			kt1=0;
			kt2=0;
		
		}
		// In ra ket qua
		{
		GPIO_SetBits(GPIOB,GPIO_Pin_0);
		GPIOA -> ODR = NUM[vrc_kq[7]];
		Delay_ms(1);
		GPIO_ResetBits(GPIOB, GPIO_Pin_0);
			
		GPIO_SetBits(GPIOB,GPIO_Pin_1);
		GPIOA -> ODR = NUM[vrc_kq[8]];
		Delay_ms(1);
		GPIO_ResetBits(GPIOB, GPIO_Pin_1);
			
			GPIO_SetBits(GPIOB,GPIO_Pin_10);
		GPIOA -> ODR = NUM[vrc_kq[9]];
		Delay_ms(1);
		GPIO_ResetBits(GPIOB, GPIO_Pin_10);
			
			GPIO_SetBits(GPIOB,GPIO_Pin_11);
		GPIOA -> ODR = NUM[vrc_kq[10]];
		Delay_ms(1);
		GPIO_ResetBits(GPIOB, GPIO_Pin_11);
			
			GPIO_SetBits(GPIOB,GPIO_Pin_5);
		GPIOA -> ODR = NUM[vrc_kq[11] ];
		Delay_ms(1);
		GPIO_ResetBits(GPIOB, GPIO_Pin_5);
			
			GPIO_SetBits(GPIOB,GPIO_Pin_6);
		GPIOA -> ODR = NUM[vrc_kq[12]];
		Delay_ms(1);
		GPIO_ResetBits(GPIOB, GPIO_Pin_6);
		
			GPIO_SetBits(GPIOB,GPIO_Pin_7);
		GPIOA -> ODR = NUM[vrc_kq[13]];
		Delay_ms(1);
		GPIO_ResetBits(GPIOB, GPIO_Pin_7);
				
			GPIO_SetBits(GPIOB,GPIO_Pin_8);
		GPIOA -> ODR = NUM[vrc_kq[14]];
		Delay_ms(1);
		GPIO_ResetBits(GPIOB, GPIO_Pin_8);
		
		}
		
	}
}




void Delay_ms(uint16_t _time){
	uint16_t i,j;
	for(i = 0; i < _time; i++){
		for(j = 0; j < 0x2AFF; j++);
	}
}

//su dung lenh printf
struct _FILE {
    int dummy;
};
FILE __stdout;
 
int fputc(int ch, FILE *f) {
 
    uart_SendChar(ch);
  
    return ch;
}



void uart_Init(void){
	GPIO_InitTypeDef gpio_typedef;
	USART_InitTypeDef usart_typedef;
	// enable clock
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1, ENABLE);
	// congifgure pin Tx - A9;
	gpio_typedef.GPIO_Pin = GPIO_Pin_9;
	gpio_typedef.GPIO_Mode = GPIO_Mode_AF_PP;
	gpio_typedef.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA,&gpio_typedef);	
	// configure pin Rx - A10;
	gpio_typedef.GPIO_Pin = GPIO_Pin_10;
	gpio_typedef.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	gpio_typedef.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA,&gpio_typedef);
	// usart configure
	usart_typedef.USART_BaudRate = 9600;
	usart_typedef.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
	usart_typedef.USART_Mode = USART_Mode_Tx | USART_Mode_Rx; 
	usart_typedef.USART_Parity = USART_Parity_No;
	usart_typedef.USART_StopBits = USART_StopBits_1;
	usart_typedef.USART_WordLength = USART_WordLength_8b;
	USART_Init(USART1, &usart_typedef);
	
	USART_ITConfig(USART1, USART_IT_RXNE, ENABLE);
	 /* Enable USART1 global interrupt */
	NVIC_EnableIRQ(USART1_IRQn);
	
	USART_Cmd(USART1, ENABLE);
}

void led_Init(void){
	
	GPIO_InitTypeDef led_init;
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO, ENABLE);
	
	led_init.GPIO_Mode = GPIO_Mode_Out_PP;
	led_init.GPIO_Pin = GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_2|GPIO_Pin_3|GPIO_Pin_4|
											GPIO_Pin_5|GPIO_Pin_6;
	led_init.GPIO_Speed = GPIO_Speed_50MHz;
	
	GPIO_Init(GPIOA,&led_init);
	
	GPIOA->ODR = 0X00;
}

void ledcontrol_Init(void){
	GPIO_InitTypeDef button_init;
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO, ENABLE);
	
	button_init.GPIO_Mode = GPIO_Mode_Out_PP;
	button_init.GPIO_Pin = GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_10|GPIO_Pin_11|GPIO_Pin_5|
											GPIO_Pin_6|GPIO_Pin_7 |GPIO_Pin_8;
	button_init.GPIO_Speed = GPIO_Speed_50MHz;
	
	GPIO_Init(GPIOB,&button_init);
	GPIOB->ODR = 0xffff;
}


void uart_SendChar(char _chr){
	USART_SendData(USART1,_chr);
	while(USART_GetFlagStatus(USART1, USART_FLAG_TXE)==RESET);
}



uint16_t UARTx_Getc(USART_TypeDef* USARTx){
	return USART_ReceiveData(USARTx);
}

void USART1_IRQHandler(){
	
	if(USART_GetITStatus(USART1, USART_IT_RXNE)!=RESET){
		vrc_Getc = UARTx_Getc(USART1);
		
		if(vrc_Getc == '-') kt1=1; //bat dau nhap so thu nhat
		if(vrc_Getc == '+') kt2=1; //bat dau nhap so thu hai
		
		if (kt1 == 1 && vrc_Getc != '-'){
			vrc_b1[vri_Count] = vrc_Getc;
			vri_Count++;

			if (vri_Count==8) {
				kt1 = 2;
				vri_Count=0;
			}
		}
		
		if (kt2 == 1 && vrc_Getc != '+' ){
			vrc_b2[vri_Count] = vrc_Getc;
			vri_Count++;
			if (vri_Count==8) {
				kt2 = 2;
				vri_Count=0;
			}
		}
	}
}
